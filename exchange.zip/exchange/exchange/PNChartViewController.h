//
//  PNChartViewController.h
//  exchange
//
//  Created by Terry on 2017/5/6.
//  Copyright © 2017年 Terry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PNChart.h"

@interface PNChartViewController : UIViewController
@property(nonatomic, retain)NSString * bank;
@property(nonatomic, retain)NSString * currency;
@end
