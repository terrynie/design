//
//  ParityXFormatter.h
//  exchange
//
//  Created by Terry on 2017/5/10.
//  Copyright © 2017年 Terry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParityXFormatter : NSObject

@end
